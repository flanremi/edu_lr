data_params = {
    'NeurIPS2020': {
        'stu_num': 2000,
        'prob_num': 454,
        'know_num': 38,
        'batch_size': 16
    },
    'XES3G5M': {
        'stu_num': 2000,
        'prob_num': 1624,
        'know_num': 241,
        'batch_size': 16
    },
    'MOOCRadar': {
        'stu_num': 2000,
        'prob_num': 915,
        'know_num': 696,
        'batch_size': 16
    },
}
